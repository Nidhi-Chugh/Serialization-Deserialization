import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Implementation
{
	public static void main(String args[])
	{
		try
		{
			serialize();
			deserialize();			
		}
		catch(IOException | ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	public static Student createStudent()
	{
		Student student = new Student();
		student.setRollno(1);
		student.setName("Nidhi Chugh");
		student.setCity("Kanpur");
		return student;
	}
	
	public static void serialize() throws IOException
	{
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("C:\\Users\\1782221\\Desktop\\Nidhi.txt"));
		oos.writeObject(createStudent());
		System.out.println("serialized data is saved in Nidhi.txt file");
	}
	
	public static void deserialize() throws IOException , ClassNotFoundException
	{
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("C:\\Users\\1782221\\Desktop\\Nidhi.txt"));
		Student chugh = (Student)ois.readObject(); 
		System.out.println("deserialized data is saved in nidhi.txt file");
	}

}
